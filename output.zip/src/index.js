require('./assets/main.svg');
